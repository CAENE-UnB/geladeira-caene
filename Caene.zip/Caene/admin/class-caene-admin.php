<?php
/**
 * A funcionalidade administrativa do plugin.
 *
 * @since      1.0.0
 */

class Caene_Admin {

    /**
     * O ID deste plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    O ID deste plugin.
     */
    private $plugin_name;

    /**
     * A versão deste plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    A versão atual deste plugin.
     */
    private $version;

    /**
     * Inicializa a classe e define suas propriedades.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       O nome do plugin.
     * @param      string    $version    A versão do plugin.
     */
    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
    }

    /**
     * Registra os estilos para a área administrativa.
     *
     * @since    1.0.0
     */
    public function enqueue_styles() {
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/caene-admin.css', array(), $this->version, 'all');
    }

    /**
     * Registra os scripts para a área administrativa.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts() {
        wp_enqueue_script('wp-color-picker');
        wp_enqueue_media();
        wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/caene-admin.js', array('jquery', 'wp-color-picker'), $this->version, false);
        
        // Adiciona o objeto de localização para o AJAX
        wp_localize_script($this->plugin_name, 'caene_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('caene-ajax-nonce')
        ));
    }

    /**
     * Adiciona o menu do plugin no painel administrativo
     *
     * @since    1.0.0
     */
    public function add_plugin_admin_menu() {
        // Menu principal
        add_menu_page(
            'Gestão de Estoque', 
            'Gestão de Estoque', 
            'manage_options', 
            $this->plugin_name, 
            array($this, 'display_plugin_admin_page'), 
            'dashicons-cart', 
            26
        );
        
        // Submenus
        add_submenu_page(
            $this->plugin_name,
            'Produtos',
            'Produtos',
            'manage_options',
            $this->plugin_name . '-produtos',
            array($this, 'display_plugin_admin_produtos')
        );
        
        add_submenu_page(
            $this->plugin_name,
            'Vendas',
            'Vendas',
            'manage_options',
            $this->plugin_name . '-vendas',
            array($this, 'display_plugin_admin_vendas')
        );
        
        add_submenu_page(
            $this->plugin_name,
            'Configurações',
            'Configurações',
            'manage_options',
            $this->plugin_name . '-configuracoes',
            array($this, 'display_plugin_admin_configuracoes')
        );
    }

    /**
     * Renderiza a página principal do plugin
     *
     * @since    1.0.0
     */
    public function display_plugin_admin_page() {
        include_once 'partials/caene-admin-display.php';
    }
    
    /**
     * Renderiza a página de produtos
     *
     * @since    1.0.0
     */
    public function display_plugin_admin_produtos() {
        include_once 'partials/caene-admin-produtos.php';
    }
    
    /**
     * Renderiza a página de vendas
     *
     * @since    1.0.0
     */
    public function display_plugin_admin_vendas() {
        include_once 'partials/caene-admin-vendas.php';
    }
    
    /**
     * Renderiza a página de configurações
     *
     * @since    1.0.0
     */
    public function display_plugin_admin_configuracoes() {
        include_once 'partials/caene-admin-configuracoes.php';
    }

    /**
     * Processa o salvamento das configurações via AJAX
     *
     * @since    1.0.0
     */
    public function ajax_save_settings() {
        // Verificar nonce para segurança
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'caene-ajax-nonce')) {
            wp_send_json_error('Erro de segurança. Tente novamente.');
        }

        // Verificar permissões
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Você não tem permissão para realizar esta ação.');
        }

        global $wpdb;
        $table_config = $wpdb->prefix . 'caene_configuracoes';

        // Sanitizar dados
        $logo_url = isset($_POST['logo_url']) ? sanitize_text_field($_POST['logo_url']) : '';
        $cor_primaria = isset($_POST['cor_primaria']) ? sanitize_text_field($_POST['cor_primaria']) : '#3498db';
        $cor_secundaria = isset($_POST['cor_secundaria']) ? sanitize_text_field($_POST['cor_secundaria']) : '#2ecc71';
        $cor_texto = isset($_POST['cor_texto']) ? sanitize_text_field($_POST['cor_texto']) : '#333333';
        $cor_fundo = isset($_POST['cor_fundo']) ? sanitize_text_field($_POST['cor_fundo']) : '#ffffff';
        $usar_gradiente = isset($_POST['usar_gradiente']) ? 1 : 0;
        $dados_servidor_uni = isset($_POST['dados_servidor_uni']) ? sanitize_textarea_field($_POST['dados_servidor_uni']) : '';

        // Atualizar no banco de dados
        $wpdb->update(
            $table_config,
            array(
                'logo_url' => $logo_url,
                'cor_primaria' => $cor_primaria,
                'cor_secundaria' => $cor_secundaria,
                'cor_texto' => $cor_texto,
                'cor_fundo' => $cor_fundo,
                'usar_gradiente' => $usar_gradiente,
                'dados_servidor_uni' => $dados_servidor_uni
            ),
            array('id' => 1)
        );

        wp_send_json_success('Configurações salvas com sucesso!');
    }

    /**
     * Processa a adição de produtos via AJAX
     *
     * @since    1.0.0
     */
    public function ajax_add_product() {
        // Verificar nonce para segurança
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'caene-ajax-nonce')) {
            wp_send_json_error('Erro de segurança. Tente novamente.');
        }

        // Verificar permissões
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Você não tem permissão para realizar esta ação.');
        }

        global $wpdb;
        $table_produtos = $wpdb->prefix . 'caene_produtos';

        // Sanitizar dados
        $nome = isset($_POST['nome']) ? sanitize_text_field($_POST['nome']) : '';
        $descricao = isset($_POST['descricao']) ? sanitize_textarea_field($_POST['descricao']) : '';
        $preco = isset($_POST['preco']) ? floatval($_POST['preco']) : 0;
        $quantidade = isset($_POST['quantidade']) ? intval($_POST['quantidade']) : 0;
        $codigo_barras = isset($_POST['codigo_barras']) ? sanitize_text_field($_POST['codigo_barras']) : '';
        $imagem = isset($_POST['imagem']) ? sanitize_text_field($_POST['imagem']) : '';
        $categoria = isset($_POST['categoria']) ? sanitize_text_field($_POST['categoria']) : '';

        // Validar dados obrigatórios
        if (empty($nome)) {
            wp_send_json_error('O nome do produto é obrigatório.');
        }

        // Inserir no banco de dados
        $wpdb->insert(
            $table_produtos,
            array(
                'nome' => $nome,
                'descricao' => $descricao,
                'preco' => $preco,
                'quantidade' => $quantidade,
                'codigo_barras' => $codigo_barras,
                'imagem' => $imagem,
                'categoria' => $categoria,
                'visivel' => 1,
                'data_criacao' => current_time('mysql')
            )
        );

        wp_send_json_success('Produto adicionado com sucesso!');
    }

    /**
     * Processa a edição de produtos via AJAX
     *
     * @since    1.0.0
     */
    public function ajax_edit_product() {
        // Verificar nonce para segurança
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'caene-ajax-nonce')) {
            wp_send_json_error('Erro de segurança. Tente novamente.');
        }

        // Verificar permissões
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Você não tem permissão para realizar esta ação.');
        }

        global $wpdb;
        $table_produtos = $wpdb->prefix . 'caene_produtos';

        // Sanitizar dados
        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        $nome = isset($_POST['nome']) ? sanitize_text_field($_POST['nome']) : '';
        $descricao = isset($_POST['descricao']) ? sanitize_textarea_field($_POST['descricao']) : '';
        $preco = isset($_POST['preco']) ? floatval($_POST['preco']) : 0;
        $quantidade = isset($_POST['quantidade']) ? intval($_POST['quantidade']) : 0;
        $codigo_barras = isset($_POST['codigo_barras']) ? sanitize_text_field($_POST['codigo_barras']) : '';
        $imagem = isset($_POST['imagem']) ? sanitize_text_field($_POST['imagem']) : '';
        $categoria = isset($_POST['categoria']) ? sanitize_text_field($_POST['categoria']) : '';
        $visivel = isset($_POST['visivel']) ? intval($_POST['visivel']) : 1;

        // Validar dados obrigatórios
        if (empty($nome)) {
            wp_send_json_error('O nome do produto é obrigatório.');
        }

        if ($id <= 0) {
            wp_send_json_error('ID do produto inválido.');
        }

        // Atualizar no banco de dados
        $wpdb->update(
            $table_produtos,
            array(
                'nome' => $nome,
                'descricao' => $descricao,
                'preco' => $preco,
                'quantidade' => $quantidade,
                'codigo_barras' => $codigo_barras,
                'imagem' => $imagem,
                'categoria' => $categoria,
                'visivel' => $visivel
            ),
            array('id' => $id)
        );

        wp_send_json_success('Produto atualizado com sucesso!');
    }

    /**
     * Processa a exclusão de produtos via AJAX
     *
     * @since    1.0.0
     */
    public function ajax_delete_product() {
        // Verificar nonce para segurança
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'caene-ajax-nonce')) {
            wp_send_json_error('Erro de segurança. Tente novamente.');
        }

        // Verificar permissões
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Você não tem permissão para realizar esta ação.');
        }

        global $wpdb;
        $table_produtos = $wpdb->prefix . 'caene_produtos';

        // Sanitizar dados
        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;

        if ($id <= 0) {
            wp_send_json_error('ID do produto inválido.');
        }

        // Excluir do banco de dados
        $wpdb->delete(
            $table_produtos,
            array('id' => $id)
        );

        wp_send_json_success('Produto excluído com sucesso!');
    }

    /**
     * Processa ações em massa de produtos via AJAX
     *
     * @since    1.0.0
     */
    public function ajax_bulk_actions() {
        // Verificar nonce para segurança
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'caene-ajax-nonce')) {
            wp_send_json_error('Erro de segurança. Tente novamente.');
        }

        // Verificar permissões
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Você não tem permissão para realizar esta ação.');
        }

        global $wpdb;
        $table_produtos = $wpdb->prefix . 'caene_produtos';

        // Sanitizar dados
        $ids = isset($_POST['ids']) ? array_map('intval', $_POST['ids']) : array();
        $action = isset($_POST['action']) ? sanitize_text_field($_POST['action']) : '';

        if (empty($ids)) {
            wp_send_json_error('Nenhum produto selecionado.');
        }

        $ids_string = implode(',', $ids);

        // Realizar ação com base no tipo
        switch ($action) {
            case 'delete':
                $wpdb->query("DELETE FROM $table_produtos WHERE id IN ($ids_string)");
                wp_send_json_success('Produtos excluídos com sucesso!');
                break;
            
            case 'hide':
                $wpdb->query("UPDATE $table_produtos SET visivel = 0 WHERE id IN ($ids_string)");
                wp_send_json_success('Produtos ocultados com sucesso!');
                break;
            
            case 'show':
                $wpdb->query("UPDATE $table_produtos SET visivel = 1 WHERE id IN ($ids_string)");
                wp_send_json_success('Produtos tornados visíveis com sucesso!');
                break;
            
            default:
                wp_send_json_error('Ação inválida.');
                break;
        }
    }

    /**
     * Processa a obtenção de vendas via AJAX
     *
     * @since    1.0.0
     */
    public function ajax_get_sales() {
        // Verificar nonce para segurança
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'caene-ajax-nonce')) {
            wp_send_json_error('Erro de segurança. Tente novamente.');
        }

        // Verificar permissões
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Você não tem permissão para realizar esta ação.');
        }

        global $wpdb;
        $table_vendas = $wpdb->prefix . 'caene_vendas';
        $table_produtos = $wpdb->prefix . 'caene_produtos';

        // Parâmetros de paginação e ordenação
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $per_page = isset($_POST['per_page']) ? intval($_POST['per_page']) : 10;
        $offset = ($page - 1) * $per_page;
        
        // Busca
        $search = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';
        $where = '';
        
        if (!empty($search)) {
            $where = $wpdb->prepare(
                "WHERE p.nome LIKE %s OR v.codigo_pagamento LIKE %s",
                '%' . $wpdb->esc_like($search) . '%',
                '%' . $wpdb->esc_like($search) . '%'
            );
        }

        // Consulta para obter as vendas com informações do produto
        $query = "
            SELECT v.*, p.nome as produto_nome 
            FROM $table_vendas v
            LEFT JOIN $table_produtos p ON v.produto_id = p.id
            $where
            ORDER BY v.data_venda DESC
            LIMIT %d OFFSET %d
        ";
        
        $vendas = $wpdb->get_results($wpdb->prepare($query, $per_page, $offset));
        
        // Contar total para paginação
        $total = $wpdb->get_var("
            SELECT COUNT(*) 
            FROM $table_vendas v
            LEFT JOIN $table_produtos p ON v.produto_id = p.id
            $where
        ");

        wp_send_json_success(array(
            'vendas' => $vendas,
            'total' => intval($total),
            'pages' => ceil($total / $per_page)
        ));
    }

    /**
     * Processa o upload de imagens via AJAX
     *
     * @since    1.0.0
     */
    public function ajax_upload_image() {
        // Verificar nonce para segurança
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'caene-ajax-nonce')) {
            wp_send_json_error('Erro de segurança. Tente novamente.');
        }

        // Verificar permissões
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Você não tem permissão para realizar esta ação.');
        }

        if (!isset($_FILES['image'])) {
            wp_send_json_error('Nenhuma imagem enviada.');
        }

        $attachment_id = media_handle_upload('image', 0);

        if (is_wp_error($attachment_id)) {
            wp_send_json_error($attachment_id->get_error_message());
        }

        $image_url = wp_get_attachment_url($attachment_id);
        
        wp_send_json_success(array(
            'url' => $image_url,
            'id' => $attachment_id
        ));
    }
}
