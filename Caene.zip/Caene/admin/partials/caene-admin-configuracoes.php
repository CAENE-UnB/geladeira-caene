<?php
/**
 * Fornece a interface para configurações do sistema
 *
 * @since      1.0.0
 */

global $wpdb;
$table_config = $wpdb->prefix . 'caene_configuracoes';

// Obter configurações atuais
$config = $wpdb->get_row("SELECT * FROM $table_config WHERE id = 1");
?>

<div class="wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <form id="caene-config-form" class="caene-form">
        <div class="caene-admin-tabs">
            <a href="#" class="caene-tab active" data-tab="aparencia">Aparência</a>
            <a href="#" class="caene-tab" data-tab="servidor">Servidor da Universidade</a>
            <a href="#" class="caene-tab" data-tab="pagamento">Configurações de Pagamento</a>
        </div>
        
        <div class="caene-admin-content">
            <div class="caene-tab-content active" id="tab-aparencia">
                <h2>Personalização da Interface</h2>
                
                <div class="caene-form-row">
                    <div class="caene-form-col full">
                        <label for="config-logo">Logo da Loja</label>
                        <div class="caene-image-upload">
                            <div id="config-logo-preview" class="caene-image-preview">
                                <?php if (!empty($config->logo_url)) : ?>
                                    <img src="<?php echo esc_url($config->logo_url); ?>" alt="Logo">
                                <?php endif; ?>
                            </div>
                            <input type="hidden" id="config-logo-url" name="logo_url" value="<?php echo esc_attr($config->logo_url); ?>">
                            <button type="button" class="button" id="config-upload-button">Selecionar Logo</button>
                            <button type="button" class="button" id="config-remove-logo" <?php echo empty($config->logo_url) ? 'style="display:none;"' : ''; ?>>Remover Logo</button>
                        </div>
                    </div>
                </div>
                
                <div class="caene-form-row">
                    <div class="caene-form-col">
                        <label for="config-cor-primaria">Cor Primária</label>
                        <input type="text" id="config-cor-primaria" name="cor_primaria" class="caene-color-picker" value="<?php echo esc_attr($config->cor_primaria); ?>">
                    </div>
                    <div class="caene-form-col">
                        <label for="config-cor-secundaria">Cor Secundária</label>
                        <input type="text" id="config-cor-secundaria" name="cor_secundaria" class="caene-color-picker" value="<?php echo esc_attr($config->cor_secundaria); ?>">
                    </div>
                </div>
                
                <div class="caene-form-row">
                    <div class="caene-form-col">
                        <label for="config-cor-texto">Cor do Texto</label>
                        <input type="text" id="config-cor-texto" name="cor_texto" class="caene-color-picker" value="<?php echo esc_attr($config->cor_texto); ?>">
                    </div>
                    <div class="caene-form-col">
                        <label for="config-cor-fundo">Cor de Fundo</label>
                        <input type="text" id="config-cor-fundo" name="cor_fundo" class="caene-color-picker" value="<?php echo esc_attr($config->cor_fundo); ?>">
                    </div>
                </div>
                
                <div class="caene-form-row">
                    <div class="caene-form-col full">
                        <label class="caene-checkbox">
                            <input type="checkbox" id="config-usar-gradiente" name="usar_gradiente" value="1" <?php checked($config->usar_gradiente, 1); ?>>
                            <span>Usar gradiente entre cor primária e secundária</span>
                        </label>
                    </div>
                </div>
                
                <div class="caene-preview-container">
                    <h3>Pré-visualização</h3>
                    <div id="caene-preview" class="caene-interface-preview">
                        <div class="caene-preview-header">
                            <div class="caene-preview-logo">LOGO</div>
                            <div class="caene-preview-menu">
                                <div class="caene-preview-menu-item active">Início</div>
                                <div class="caene-preview-menu-item">Produtos</div>
                                <div class="caene-preview-menu-item">Carrinho</div>
                            </div>
                        </div>
                        <div class="caene-preview-content">
                            <div class="caene-preview-card">
                                <div class="caene-preview-product"></div>
                                <div class="caene-preview-product-info">
                                    <div class="caene-preview-product-title">Nome do Produto</div>
                                    <div class="caene-preview-product-price">R$ 99,90</div>
                                    <div class="caene-preview-product-button">Comprar</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="caene-tab-content" id="tab-servidor">
                <h2>Integração com Servidor da Universidade</h2>
                
                <div class="caene-form-row">
                    <div class="caene-form-col full">
                        <label for="config-dados-servidor">Dados de Configuração do Servidor</label>
                        <textarea id="config-dados-servidor" name="dados_servidor_uni" rows="6"><?php echo esc_textarea($config->dados_servidor_uni); ?></textarea>
                        <p class="description">Configure a integração com o servidor da sua universidade. Informe os dados de conexão no formato JSON:</p>
                        <pre>{
  "servidor": "https://exemplo.universidade.edu.br",
  "api_key": "sua_chave_api",
  "departamento": "seu_departamento",
  "pasta_destino": "caminho/da/pasta"
}</pre>
                    </div>
                </div>
                
                <div class="caene-form-row">
                    <div class="caene-form-col">
                        <button type="button" class="button" id="caene-test-servidor">Testar Conexão</button>
                    </div>
                </div>
                
                <div id="caene-test-result" class="caene-message" style="display:none;"></div>
            </div>
            
            <div class="caene-tab-content" id="tab-pagamento">
                <h2>Configurações de Pagamento</h2>
                
                <div class="caene-form-row">
                    <div class="caene-form-col full">
                        <h3>QR Code de Pagamento</h3>
                        <p>O sistema gera automaticamente QR Codes para pagamento de produtos utilizando o padrão PIX com CRC automático.</p>
                        <p>Para cada produto, um QR Code único será gerado contendo:</p>
                        <ul>
                            <li>Código do produto</li>
                            <li>Valor</li>
                            <li>Identificação da compra</li>
                            <li>CRC de verificação</li>
                        </ul>
                    </div>
                </div>
                
                <div class="caene-form-row">
                    <div class="caene-form-col full">
                        <label class="caene-checkbox">
                            <input type="checkbox" id="config-qrcode-automatico" name="qrcode_automatico" value="1" checked>
                            <span>Gerar QR Code automaticamente para novos produtos</span>
                        </label>
                    </div>
                </div>
                
                <div class="caene-form-row">
                    <div class="caene-form-col full">
                        <label class="caene-checkbox">
                            <input type="checkbox" id="config-qrcode-pix" name="qrcode_pix" value="1" checked>
                            <span>Usar formato compatível com PIX</span>
                        </label>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="caene-form-actions">
            <button type="submit" class="button button-primary">Salvar Configurações</button>
            <button type="button" class="button" id="caene-reset-config">Restaurar Padrões</button>
        </div>
    </form>
</div>
