<?php
/**
 * Fornece a interface para visualização e gerenciamento de vendas
 *
 * @since      1.0.0
 */
?>

<div class="wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <div class="caene-toolbar">
        <div class="caene-search">
            <input type="text" id="caene-search-vendas" placeholder="Buscar vendas...">
            <button type="button" class="button" id="caene-search-vendas-button">Buscar</button>
        </div>
        <div class="caene-filter">
            <select id="caene-filter-status">
                <option value="">Todos os status</option>
                <option value="pendente">Pendente</option>
                <option value="aprovado">Aprovado</option>
                <option value="cancelado">Cancelado</option>
            </select>
            <input type="date" id="caene-filter-data-inicio" placeholder="Data início">
            <input type="date" id="caene-filter-data-fim" placeholder="Data fim">
            <button type="button" class="button" id="caene-filter-vendas-button">Filtrar</button>
        </div>
        <div class="caene-export">
            <button type="button" class="button" id="caene-export-csv">Exportar CSV</button>
            <button type="button" class="button" id="caene-export-pdf">Exportar PDF</button>
        </div>
    </div>
    
    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Produto</th>
                <th>Quantidade</th>
                <th>Valor Total</th>
                <th>Data da Venda</th>
                <th>Status</th>
                <th>Código de Pagamento</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody id="caene-vendas-lista">
            <tr>
                <td colspan="8" class="caene-loading">Carregando vendas...</td>
            </tr>
        </tbody>
    </table>
    
    <div class="caene-pagination">
        <div class="caene-pagination-info">
            Mostrando <span id="caene-pagination-showing">0</span> de <span id="caene-pagination-total">0</span> vendas
        </div>
        <div class="caene-pagination-controls">
            <button type="button" class="button" id="caene-pagination-prev" disabled>Anterior</button>
            <span id="caene-pagination-current">Página 1</span>
            <button type="button" class="button" id="caene-pagination-next" disabled>Próximo</button>
        </div>
    </div>
</div>

<!-- Modal para detalhes da venda -->
<div id="caene-venda-modal" class="caene-modal">
    <div class="caene-modal-content">
        <span class="caene-modal-close">&times;</span>
        <h2>Detalhes da Venda</h2>
        <div id="caene-venda-detalhes">
            <div class="caene-venda-info">
                <div class="caene-venda-produto">
                    <h3>Informações do Produto</h3>
                    <p><strong>Nome:</strong> <span id="venda-produto-nome"></span></p>
                    <p><strong>Código:</strong> <span id="venda-produto-codigo"></span></p>
                    <p><strong>Preço unitário:</strong> R$ <span id="venda-produto-preco"></span></p>
                </div>
                <div class="caene-venda-pagamento">
                    <h3>Informações do Pagamento</h3>
                    <p><strong>Quantidade:</strong> <span id="venda-quantidade"></span></p>
                    <p><strong>Valor total:</strong> R$ <span id="venda-valor-total"></span></p>
                    <p><strong>Data/Hora:</strong> <span id="venda-data"></span></p>
                    <p><strong>Status:</strong> <span id="venda-status"></span></p>
                    <p><strong>Código de pagamento:</strong> <span id="venda-codigo"></span></p>
                </div>
            </div>
            
            <div class="caene-venda-qrcode">
                <h3>QR Code de Pagamento</h3>
                <div id="venda-qrcode-image"></div>
            </div>
        </div>
        
        <div class="caene-venda-actions">
            <select id="caene-update-status">
                <option value="">Atualizar status</option>
                <option value="pendente">Pendente</option>
                <option value="aprovado">Aprovado</option>
                <option value="cancelado">Cancelado</option>
            </select>
            <button type="button" class="button button-primary" id="caene-save-status">Salvar Status</button>
            <button type="button" class="button" id="caene-download-comprovante">Baixar Comprovante</button>
        </div>
    </div>
</div>
