<?php
/**
 * Fornece a interface para gerenciamento de produtos
 *
 * @since      1.0.0
 */

global $wpdb;
$table_produtos = $wpdb->prefix . 'caene_produtos';

// Obter lista de produtos para exibir
$produtos = $wpdb->get_results("SELECT * FROM $table_produtos ORDER BY nome ASC");
?>

<div class="wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <div class="caene-admin-tabs">
        <a href="#" class="caene-tab active" data-tab="list">Lista de Produtos</a>
        <a href="#" class="caene-tab" data-tab="add">Adicionar Novo</a>
    </div>
    
    <div class="caene-admin-content">
        <div class="caene-tab-content active" id="tab-list">
            <div class="caene-toolbar">
                <div class="caene-search">
                    <input type="text" id="caene-search-products" placeholder="Buscar produtos...">
                    <button type="button" class="button" id="caene-search-button">Buscar</button>
                </div>
                <div class="caene-bulk-actions">
                    <select id="caene-bulk-action">
                        <option value="">Ações em massa</option>
                        <option value="delete">Excluir</option>
                        <option value="hide">Ocultar</option>
                        <option value="show">Mostrar</option>
                    </select>
                    <button type="button" class="button" id="caene-apply-bulk">Aplicar</button>
                </div>
            </div>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th width="20"><input type="checkbox" id="caene-select-all"></th>
                        <th width="60">Imagem</th>
                        <th>Nome</th>
                        <th>Descrição</th>
                        <th width="100">Preço</th>
                        <th width="100">Quantidade</th>
                        <th width="100">Status</th>
                        <th width="150">Ações</th>
                    </tr>
                </thead>
                <tbody id="caene-produtos-lista">
                    <?php
                    if ($produtos) {
                        foreach ($produtos as $produto) {
                            ?>
                            <tr data-id="<?php echo esc_attr($produto->id); ?>">
                                <td><input type="checkbox" class="caene-select-product" value="<?php echo esc_attr($produto->id); ?>"></td>
                                <td>
                                    <?php if (!empty($produto->imagem)) : ?>
                                        <img src="<?php echo esc_url($produto->imagem); ?>" width="50" height="50" alt="<?php echo esc_attr($produto->nome); ?>">
                                    <?php else : ?>
                                        <div class="caene-no-image">Sem imagem</div>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo esc_html($produto->nome); ?></td>
                                <td><?php echo wp_trim_words(esc_html($produto->descricao), 10, '...'); ?></td>
                                <td>R$ <?php echo number_format($produto->preco, 2, ',', '.'); ?></td>
                                <td><?php echo esc_html($produto->quantidade); ?></td>
                                <td>
                                    <span class="status-badge status-<?php echo $produto->visivel ? 'visivel' : 'oculto'; ?>">
                                        <?php echo $produto->visivel ? 'Visível' : 'Oculto'; ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="row-actions">
                                        <a href="#" class="caene-edit-produto" data-id="<?php echo esc_attr($produto->id); ?>">Editar</a> | 
                                        <a href="#" class="caene-delete-produto" data-id="<?php echo esc_attr($produto->id); ?>">Excluir</a> |
                                        <a href="#" class="caene-qrcode-produto" data-id="<?php echo esc_attr($produto->id); ?>">QR Code</a>
                                    </div>
                                </td>
                            </tr>
                            <?php
                        }
                    } else {
                        ?>
                        <tr>
                            <td colspan="8">Nenhum produto cadastrado ainda.</td>
                        </tr>
                        <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
        
        <div class="caene-tab-content" id="tab-add">
            <form id="caene-produto-form" class="caene-form">
                <input type="hidden" id="produto-id" name="id" value="0">
                
                <div class="caene-form-row">
                    <div class="caene-form-col">
                        <label for="produto-nome">Nome do Produto *</label>
                        <input type="text" id="produto-nome" name="nome" required>
                    </div>
                    <div class="caene-form-col">
                        <label for="produto-categoria">Categoria</label>
                        <input type="text" id="produto-categoria" name="categoria">
                    </div>
                </div>
                
                <div class="caene-form-row">
                    <div class="caene-form-col">
                        <label for="produto-preco">Preço (R$) *</label>
                        <input type="number" id="produto-preco" name="preco" step="0.01" min="0" required>
                    </div>
                    <div class="caene-form-col">
                        <label for="produto-quantidade">Quantidade em Estoque *</label>
                        <input type="number" id="produto-quantidade" name="quantidade" min="0" required>
                    </div>
                </div>
                
                <div class="caene-form-row">
                    <div class="caene-form-col">
                        <label for="produto-codigo">Código de Barras</label>
                        <input type="text" id="produto-codigo" name="codigo_barras">
                    </div>
                    <div class="caene-form-col">
                        <label for="produto-visivel">Status</label>
                        <select id="produto-visivel" name="visivel">
                            <option value="1">Visível</option>
                            <option value="0">Oculto</option>
                        </select>
                    </div>
                </div>
                
                <div class="caene-form-row">
                    <div class="caene-form-col full">
                        <label for="produto-descricao">Descrição</label>
                        <textarea id="produto-descricao" name="descricao" rows="4"></textarea>
                    </div>
                </div>
                
                <div class="caene-form-row">
                    <div class="caene-form-col full">
                        <label for="produto-imagem">Imagem do Produto</label>
                        <div class="caene-image-upload">
                            <div id="produto-imagem-preview" class="caene-image-preview"></div>
                            <input type="hidden" id="produto-imagem-url" name="imagem">
                            <button type="button" class="button" id="produto-upload-button">Selecionar Imagem</button>
                            <button type="button" class="button" id="produto-remove-image" style="display:none;">Remover Imagem</button>
                        </div>
                    </div>
                </div>
                
                <div class="caene-form-actions">
                    <button type="submit" class="button button-primary">Salvar Produto</button>
                    <button type="button" class="button" id="caene-cancel-edit">Cancelar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal para QR Code de Pagamento -->
<div id="caene-qrcode-modal" class="caene-modal">
    <div class="caene-modal-content">
        <span class="caene-modal-close">&times;</span>
        <h2>QR Code de Pagamento</h2>
        <div class="caene-qrcode-container">
            <div id="caene-qrcode-image"></div>
            <div id="caene-qrcode-info">
                <p><strong>Produto:</strong> <span id="qrcode-produto-nome"></span></p>
                <p><strong>Valor:</strong> R$ <span id="qrcode-produto-valor"></span></p>
                <p><strong>Código:</strong> <span id="qrcode-produto-codigo"></span></p>
                <p>Escaneie o código acima para realizar o pagamento</p>
            </div>
        </div>
        <div class="caene-modal-actions">
            <button type="button" class="button" id="caene-download-qrcode">Baixar QR Code</button>
            <button type="button" class="button" id="caene-print-qrcode">Imprimir</button>
        </div>
    </div>
</div>

<!-- Modal de confirmação para exclusão -->
<div id="caene-confirm-modal" class="caene-modal">
    <div class="caene-modal-content">
        <span class="caene-modal-close">&times;</span>
        <h2>Confirmação</h2>
        <p>Tem certeza que deseja excluir este produto?</p>
        <div class="caene-modal-actions">
            <button type="button" class="button button-primary" id="caene-confirm-delete">Sim, Excluir</button>
            <button type="button" class="button" id="caene-cancel-delete">Cancelar</button>
        </div>
    </div>
</div>
