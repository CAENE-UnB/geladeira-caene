<?php
/**
 * Fornece uma visão geral da área administrativa
 *
 * @since      1.0.0
 */
?>

<div class="wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    <div class="caene-dashboard">
        <div class="caene-card">
            <h2><span class="dashicons dashicons-chart-bar"></span> Resumo</h2>
            <?php
            global $wpdb;
            $table_produtos = $wpdb->prefix . 'caene_produtos';
            $table_vendas = $wpdb->prefix . 'caene_vendas';
            
            $total_produtos = $wpdb->get_var("SELECT COUNT(*) FROM $table_produtos");
            $produtos_ativos = $wpdb->get_var("SELECT COUNT(*) FROM $table_produtos WHERE visivel = 1");
            $total_vendas = $wpdb->get_var("SELECT COUNT(*) FROM $table_vendas");
            $valor_vendas = $wpdb->get_var("SELECT SUM(valor_total) FROM $table_vendas");
            
            $valor_vendas = $valor_vendas ? number_format($valor_vendas, 2, ',', '.') : '0,00';
            ?>
            <div class="caene-stats">
                <div class="caene-stat-item">
                    <span class="caene-stat-value"><?php echo esc_html($total_produtos); ?></span>
                    <span class="caene-stat-label">Produtos cadastrados</span>
                </div>
                <div class="caene-stat-item">
                    <span class="caene-stat-value"><?php echo esc_html($produtos_ativos); ?></span>
                    <span class="caene-stat-label">Produtos ativos</span>
                </div>
                <div class="caene-stat-item">
                    <span class="caene-stat-value"><?php echo esc_html($total_vendas); ?></span>
                    <span class="caene-stat-label">Vendas realizadas</span>
                </div>
                <div class="caene-stat-item">
                    <span class="caene-stat-value">R$ <?php echo esc_html($valor_vendas); ?></span>
                    <span class="caene-stat-label">Valor total vendido</span>
                </div>
            </div>
        </div>
        
        <div class="caene-card">
            <h2><span class="dashicons dashicons-cart"></span> Últimas Vendas</h2>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Produto</th>
                        <th>Quantidade</th>
                        <th>Valor</th>
                        <th>Data</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $vendas = $wpdb->get_results("
                        SELECT v.*, p.nome as produto_nome 
                        FROM $table_vendas v
                        LEFT JOIN $table_produtos p ON v.produto_id = p.id
                        ORDER BY v.data_venda DESC
                        LIMIT 5
                    ");
                    
                    if ($vendas) {
                        foreach ($vendas as $venda) {
                            ?>
                            <tr>
                                <td><?php echo esc_html($venda->produto_nome); ?></td>
                                <td><?php echo esc_html($venda->quantidade); ?></td>
                                <td>R$ <?php echo number_format($venda->valor_total, 2, ',', '.'); ?></td>
                                <td><?php echo date_i18n('d/m/Y H:i', strtotime($venda->data_venda)); ?></td>
                                <td>
                                    <span class="status-badge status-<?php echo esc_attr($venda->status_pagamento); ?>">
                                        <?php echo esc_html(ucfirst($venda->status_pagamento)); ?>
                                    </span>
                                </td>
                            </tr>
                            <?php
                        }
                    } else {
                        ?>
                        <tr>
                            <td colspan="5">Nenhuma venda registrada ainda.</td>
                        </tr>
                        <?php
                    }
                    ?>
                </tbody>
            </table>
            <p>
                <a href="<?php echo admin_url('admin.php?page=' . $this->plugin_name . '-vendas'); ?>" class="button">
                    Ver todas as vendas
                </a>
            </p>
        </div>
        
        <div class="caene-card">
            <h2><span class="dashicons dashicons-admin-tools"></span> Acesso Rápido</h2>
            <div class="caene-quick-links">
                <a href="<?php echo admin_url('admin.php?page=' . $this->plugin_name . '-produtos'); ?>" class="caene-quick-link">
                    <span class="dashicons dashicons-plus"></span> Adicionar Produto
                </a>
                <a href="<?php echo admin_url('admin.php?page=' . $this->plugin_name . '-configuracoes'); ?>" class="caene-quick-link">
                    <span class="dashicons dashicons-admin-appearance"></span> Personalizar Interface
                </a>
                <a href="<?php echo get_permalink(get_page_by_path('caene-gestao-estoque')); ?>" class="caene-quick-link" target="_blank">
                    <span class="dashicons dashicons-visibility"></span> Ver Loja
                </a>
                <a href="https://github.com/caene/gestao-estoque/wiki" class="caene-quick-link" target="_blank">
                    <span class="dashicons dashicons-book"></span> Documentação
                </a>
            </div>
        </div>
    </div>
</div>
