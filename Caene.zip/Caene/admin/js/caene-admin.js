/**
 * JavaScript para o painel administrativo do plugin Caene Gestão de Estoque
 */
(function($) {
    'use strict';

    // Variáveis globais
    let productIdToDelete = 0;
    let currentPage = 1;
    let totalPages = 1;
    let searchTerm = '';
    let currentStatus = '';
    let vendaIdAtual = 0;

    // Inicialização ao carregar a página
    $(document).ready(function() {
        // Inicializar color picker
        $('.caene-color-picker').wpColorPicker({
            change: function(event, ui) {
                atualizarPreview();
            }
        });

        // Inicializar tabs
        $('.caene-tab').on('click', function(e) {
            e.preventDefault();
            const tab = $(this).data('tab');
            
            $('.caene-tab').removeClass('active');
            $(this).addClass('active');
            
            $('.caene-tab-content').removeClass('active');
            $('#tab-' + tab).addClass('active');
        });

        // Upload de imagem para produtos
        $('#produto-upload-button').on('click', function(e) {
            e.preventDefault();
            
            const frame = wp.media({
                title: 'Selecionar ou Fazer Upload de uma Imagem',
                button: {
                    text: 'Usar esta imagem'
                },
                multiple: false
            });
            
            frame.on('select', function() {
                const attachment = frame.state().get('selection').first().toJSON();
                $('#produto-imagem-preview').html('<img src="' + attachment.url + '" alt="Prévia">');
                $('#produto-imagem-url').val(attachment.url);
                $('#produto-remove-image').show();
            });
            
            frame.open();
        });
        
        // Remover imagem do produto
        $('#produto-remove-image').on('click', function(e) {
            e.preventDefault();
            $('#produto-imagem-preview').html('');
            $('#produto-imagem-url').val('');
            $(this).hide();
        });
        
        // Upload de logo nas configurações
        $('#config-upload-button').on('click', function(e) {
            e.preventDefault();
            
            const frame = wp.media({
                title: 'Selecionar ou Fazer Upload de uma Logo',
                button: {
                    text: 'Usar esta logo'
                },
                multiple: false
            });
            
            frame.on('select', function() {
                const attachment = frame.state().get('selection').first().toJSON();
                $('#config-logo-preview').html('<img src="' + attachment.url + '" alt="Logo">');
                $('#config-logo-url').val(attachment.url);
                $('#config-remove-logo').show();
                atualizarPreview();
            });
            
            frame.open();
        });
        
        // Remover logo das configurações
        $('#config-remove-logo').on('click', function(e) {
            e.preventDefault();
            $('#config-logo-preview').html('');
            $('#config-logo-url').val('');
            $(this).hide();
            atualizarPreview();
        });
        
        // Salvar configurações
        $('#caene-config-form').on('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            formData.append('action', 'caene_save_settings');
            formData.append('nonce', caene_ajax.nonce);
            
            // Adicionar checkboxes
            formData.append('usar_gradiente', $('#config-usar-gradiente').is(':checked') ? 1 : 0);
            
            $.ajax({
                url: caene_ajax.ajax_url,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        mostrarMensagem('success', response.data);
                    } else {
                        mostrarMensagem('error', response.data);
                    }
                },
                error: function() {
                    mostrarMensagem('error', 'Erro ao salvar as configurações. Tente novamente.');
                }
            });
        });
        
        // Testar conexão com servidor da universidade
        $('#caene-test-servidor').on('click', function() {
            const dadosServidor = $('#config-dados-servidor').val();
            
            if (!dadosServidor) {
                mostrarMensagem('error', 'Por favor, insira os dados de configuração do servidor.');
                return;
            }
            
            try {
                // Verificar se o JSON é válido
                JSON.parse(dadosServidor);
                
                // Simular teste de conexão
                $('#caene-test-result').html('Testando conexão...').removeClass('success error').addClass('info').show();
                
                setTimeout(function() {
                    $('#caene-test-result').html('Conexão estabelecida com sucesso! O servidor está acessível.').removeClass('info').addClass('success');
                }, 1500);
                
            } catch (e) {
                mostrarMensagem('error', 'Os dados do servidor não estão em um formato JSON válido. Verifique e tente novamente.');
            }
        });
        
        // Restaurar configurações padrão
        $('#caene-reset-config').on('click', function() {
            if (confirm('Tem certeza que deseja restaurar todas as configurações para os valores padrão?')) {
                $('#config-logo-preview').html('');
                $('#config-logo-url').val('');
                $('#config-remove-logo').hide();
                
                $('#config-cor-primaria').wpColorPicker('color', '#3498db');
                $('#config-cor-secundaria').wpColorPicker('color', '#2ecc71');
                $('#config-cor-texto').wpColorPicker('color', '#333333');
                $('#config-cor-fundo').wpColorPicker('color', '#ffffff');
                
                $('#config-usar-gradiente').prop('checked', false);
                $('#config-dados-servidor').val('');
                
                atualizarPreview();
                
                mostrarMensagem('info', 'Configurações restauradas para os valores padrão. Clique em "Salvar Configurações" para aplicar as mudanças.');
            }
        });
        
        // Atualizar preview quando mudar o checkbox de gradiente
        $('#config-usar-gradiente').on('change', function() {
            atualizarPreview();
        });
        
        // Formulário de produto
        $('#caene-produto-form').on('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const produtoId = $('#produto-id').val();
            
            formData.append('action', produtoId == '0' ? 'caene_add_product' : 'caene_edit_product');
            formData.append('nonce', caene_ajax.nonce);
            
            $.ajax({
                url: caene_ajax.ajax_url,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        mostrarMensagem('success', response.data);
                        // Recarregar a página após 1 segundo para atualizar a lista
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        mostrarMensagem('error', response.data);
                    }
                },
                error: function() {
                    mostrarMensagem('error', 'Erro ao salvar o produto. Tente novamente.');
                }
            });
        });
        
        // Cancelar edição de produto
        $('#caene-cancel-edit').on('click', function() {
            $('#caene-produto-form')[0].reset();
            $('#produto-id').val('0');
            $('#produto-imagem-preview').html('');
            $('#produto-imagem-url').val('');
            $('#produto-remove-image').hide();
            
            // Voltar para a aba de lista
            $('.caene-tab[data-tab="list"]').trigger('click');
        });
        
        // Editar produto
        $(document).on('click', '.caene-edit-produto', function(e) {
            e.preventDefault();
            
            const produtoId = $(this).data('id');
            const row = $(this).closest('tr');
            
            // Preencher o formulário com os dados da linha
            $('#produto-id').val(produtoId);
            $('#produto-nome').val(row.find('td:eq(2)').text());
            $('#produto-descricao').val(row.find('td:eq(3)').text().replace('...', ''));
            $('#produto-preco').val(row.find('td:eq(4)').text().replace('R$ ', '').replace('.', '').replace(',', '.'));
            $('#produto-quantidade').val(row.find('td:eq(5)').text());
            $('#produto-visivel').val(row.find('.status-badge').hasClass('status-visivel') ? '1' : '0');
            
            // Imagem do produto
            const imgSrc = row.find('td:eq(1) img').attr('src');
            if (imgSrc) {
                $('#produto-imagem-preview').html('<img src="' + imgSrc + '" alt="Prévia">');
                $('#produto-imagem-url').val(imgSrc);
                $('#produto-remove-image').show();
            } else {
                $('#produto-imagem-preview').html('');
                $('#produto-imagem-url').val('');
                $('#produto-remove-image').hide();
            }
            
            // Ir para a aba de edição
            $('.caene-tab[data-tab="add"]').trigger('click');
        });
        
        // Excluir produto - abrir modal de confirmação
        $(document).on('click', '.caene-delete-produto', function(e) {
            e.preventDefault();
            
            productIdToDelete = $(this).data('id');
            $('#caene-confirm-modal').fadeIn();
        });
        
        // Confirmar exclusão de produto
        $('#caene-confirm-delete').on('click', function() {
            if (productIdToDelete > 0) {
                $.ajax({
                    url: caene_ajax.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'caene_delete_product',
                        id: productIdToDelete,
                        nonce: caene_ajax.nonce
                    },
                    success: function(response) {
                        $('#caene-confirm-modal').fadeOut();
                        
                        if (response.success) {
                            mostrarMensagem('success', response.data);
                            // Remover a linha da tabela
                            $('tr[data-id="' + productIdToDelete + '"]').fadeOut(400, function() {
                                $(this).remove();
                            });
                        } else {
                            mostrarMensagem('error', response.data);
                        }
                    },
                    error: function() {
                        $('#caene-confirm-modal').fadeOut();
                        mostrarMensagem('error', 'Erro ao excluir o produto. Tente novamente.');
                    }
                });
            }
        });
        
        // Cancelar exclusão
        $('#caene-cancel-delete, .caene-modal-close').on('click', function() {
            $('#caene-confirm-modal').fadeOut();
            $('#caene-qrcode-modal').fadeOut();
            $('#caene-venda-modal').fadeOut();
        });
        
        // Seleção em massa de produtos
        $('#caene-select-all').on('change', function() {
            $('.caene-select-product').prop('checked', $(this).is(':checked'));
        });
        
        // Ações em massa
        $('#caene-apply-bulk').on('click', function() {
            const action = $('#caene-bulk-action').val();
            const selectedProducts = $('.caene-select-product:checked');
            
            if (!action) {
                mostrarMensagem('error', 'Selecione uma ação para aplicar.');
                return;
            }
            
            if (selectedProducts.length === 0) {
                mostrarMensagem('error', 'Selecione pelo menos um produto.');
                return;
            }
            
            const productIds = [];
            selectedProducts.each(function() {
                productIds.push($(this).val());
            });
            
            $.ajax({
                url: caene_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'caene_bulk_actions',
                    bulk_action: action,
                    ids: productIds,
                    nonce: caene_ajax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        mostrarMensagem('success', response.data);
                        // Recarregar a página após 1 segundo para atualizar a lista
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        mostrarMensagem('error', response.data);
                    }
                },
                error: function() {
                    mostrarMensagem('error', 'Erro ao aplicar a ação em massa. Tente novamente.');
                }
            });
        });
        
        // Gerar QR Code para produto
        $(document).on('click', '.caene-qrcode-produto', function(e) {
            e.preventDefault();
            
            const produtoId = $(this).data('id');
            const row = $(this).closest('tr');
            
            // Preencher informações do QR Code
            $('#qrcode-produto-nome').text(row.find('td:eq(2)').text());
            $('#qrcode-produto-valor').text(row.find('td:eq(4)').text().replace('R$ ', ''));
            $('#qrcode-produto-codigo').text(produtoId);
            
            // Gerar QR Code
            gerarQRCode(produtoId, row.find('td:eq(2)').text(), row.find('td:eq(4)').text().replace('R$ ', '').replace('.', '').replace(',', '.'));
            
            // Exibir modal
            $('#caene-qrcode-modal').fadeIn();
        });
        
        // Baixar QR Code
        $('#caene-download-qrcode').on('click', function() {
            // Simulação de download do QR Code
            const canvas = $('#caene-qrcode-image canvas').get(0);
            
            if (canvas) {
                const dataUrl = canvas.toDataURL('image/png');
                const a = document.createElement('a');
                a.href = dataUrl;
                a.download = 'qrcode-produto-' + $('#qrcode-produto-codigo').text() + '.png';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
            }
        });
        
        // Imprimir QR Code
        $('#caene-print-qrcode').on('click', function() {
            const printWindow = window.open('', '_blank');
            const canvas = $('#caene-qrcode-image canvas').get(0);
            
            if (canvas) {
                const dataUrl = canvas.toDataURL('image/png');
                printWindow.document.write(`
                    <html>
                        <head>
                            <title>QR Code - ${$('#qrcode-produto-nome').text()}</title>
                            <style>
                                body { font-family: Arial, sans-serif; text-align: center; }
                                .qrcode-container { margin: 20px auto; max-width: 300px; }
                                img { max-width: 100%; }
                                .info { margin-top: 20px; }
                            </style>
                        </head>
                        <body>
                            <div class="qrcode-container">
                                <img src="${dataUrl}" alt="QR Code">
                                <div class="info">
                                    <p><strong>Produto:</strong> ${$('#qrcode-produto-nome').text()}</p>
                                    <p><strong>Valor:</strong> R$ ${$('#qrcode-produto-valor').text()}</p>
                                    <p><strong>Código:</strong> ${$('#qrcode-produto-codigo').text()}</p>
                                </div>
                            </div>
                            <script>
                                window.onload = function() { window.print(); window.close(); };
                            </script>
                        </body>
                    </html>
                `);
                printWindow.document.close();
            }
        });
        
        // Carregar vendas na página de vendas
        if ($('#caene-vendas-lista').length) {
            carregarVendas();
            
            // Paginação
            $('#caene-pagination-prev').on('click', function() {
                if (currentPage > 1) {
                    currentPage--;
                    carregarVendas();
                }
            });
            
            $('#caene-pagination-next').on('click', function() {
                if (currentPage < totalPages) {
                    currentPage++;
                    carregarVendas();
                }
            });
            
            // Busca de vendas
            $('#caene-search-vendas-button').on('click', function() {
                searchTerm = $('#caene-search-vendas').val();
                currentPage = 1;
                carregarVendas();
            });
            
            // Filtro de vendas
            $('#caene-filter-vendas-button').on('click', function() {
                currentStatus = $('#caene-filter-status').val();
                // Implementar filtro por data posteriormente
                currentPage = 1;
                carregarVendas();
            });
            
            // Exportar vendas para CSV
            $('#caene-export-csv').on('click', function() {
                exportarVendas('csv');
            });
            
            // Exportar vendas para PDF
            $('#caene-export-pdf').on('click', function() {
                exportarVendas('pdf');
            });
        }
        
        // Atualizar preview inicial
        atualizarPreview();
    });
    
    // Função para exibir mensagem de sucesso/erro
    function mostrarMensagem(tipo, mensagem) {
        // Remover mensagens existentes
        $('.caene-message').remove();
        
        // Criar nova mensagem
        const messageHtml = `<div class="caene-message ${tipo}">${mensagem}</div>`;
        
        // Inserir após o primeiro h1
        $('.wrap h1').after(messageHtml);
        
        // Esconder após 5 segundos
        setTimeout(function() {
            $('.caene-message').fadeOut(500, function() {
                $(this).remove();
            });
        }, 5000);
    }
    
    // Função para atualizar o preview de interface
    function atualizarPreview() {
        const corPrimaria = $('#config-cor-primaria').val();
        const corSecundaria = $('#config-cor-secundaria').val();
        const corTexto = $('#config-cor-texto').val();
        const corFundo = $('#config-cor-fundo').val();
        const usarGradiente = $('#config-usar-gradiente').is(':checked');
        
        const preview = $('#caene-preview');
        
        preview.css('--cor-primaria', corPrimaria);
        preview.css('--cor-secundaria', corSecundaria);
        preview.css('--cor-texto', corTexto);
        preview.css('--cor-fundo', corFundo);
        
        // Aplicar gradiente ou cor sólida no cabeçalho
        const header = $('.caene-preview-header');
        if (usarGradiente) {
            header.css('background', `linear-gradient(135deg, ${corPrimaria}, ${corSecundaria})`);
        } else {
            header.css('background', corPrimaria);
            header.css('background-image', 'none');
        }
        
        // Atualizar logo no preview
        const logoUrl = $('#config-logo-url').val();
        if (logoUrl) {
            $('.caene-preview-logo').html('<img src="' + logoUrl + '" alt="Logo" style="max-height: 30px;">');
        } else {
            $('.caene-preview-logo').html('LOGO');
        }
    }
    
    // Função para gerar QR Code
    function gerarQRCode(id, nome, valor) {
        // Preparar dados para o QR Code
        const dadosQRCode = {
            id: id,
            nome: nome,
            valor: valor,
            timestamp: new Date().getTime()
        };
        
        // Calcular CRC (simulado)
        const dadosString = JSON.stringify(dadosQRCode);
        const crc = calcularCRC(dadosString);
        
        // Adicionar CRC aos dados
        dadosQRCode.crc = crc;
        
        // Criar código para pagamento
        const codigoPagamento = 'CAENE' + id + crc;
        
        // Exibir código
        $('#qrcode-produto-codigo').text(codigoPagamento);
        
        // Limpar container do QR Code
        $('#caene-qrcode-image').empty();
        
        // Criar QR Code usando a biblioteca qrcode.js (simulado)
        const qrCodeContainer = document.getElementById('caene-qrcode-image');
        const canvas = document.createElement('canvas');
        canvas.width = 200;
        canvas.height = 200;
        const ctx = canvas.getContext('2d');
        
        // Desenhar QR Code simulado
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, 200, 200);
        
        ctx.fillStyle = '#000000';
        ctx.fillRect(40, 40, 120, 120);
        
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(60, 60, 80, 80);
        
        ctx.fillStyle = '#000000';
        ctx.fillRect(70, 70, 20, 20);
        ctx.fillRect(110, 70, 20, 20);
        ctx.fillRect(70, 110, 20, 20);
        ctx.fillRect(110, 110, 20, 20);
        
        qrCodeContainer.appendChild(canvas);
    }
    
    // Função para calcular CRC (simulado)
    function calcularCRC(str) {
        let crc = 0;
        for (let i = 0; i < str.length; i++) {
            crc = (crc + str.charCodeAt(i)) % 10000;
        }
        return crc.toString().padStart(4, '0');
    }
    
    // Função para carregar vendas
    function carregarVendas() {
        $('#caene-vendas-lista').html('<tr><td colspan="8" class="caene-loading">Carregando vendas...</td></tr>');
        
        $.ajax({
            url: caene_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'caene_get_sales',
                page: currentPage,
                per_page: 10,
                search: searchTerm,
                status: currentStatus,
                nonce: caene_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    const vendas = response.data.vendas;
                    totalPages = response.data.pages;
                    
                    let html = '';
                    
                    if (vendas.length > 0) {
                        vendas.forEach(function(venda) {
                            html += `
                                <tr data-id="${venda.id}">
                                    <td>${venda.id}</td>
                                    <td>${venda.produto_nome}</td>
                                    <td>${venda.quantidade}</td>
                                    <td>R$ ${parseFloat(venda.valor_total).toFixed(2).replace('.', ',')}</td>
                                    <td>${formatarData(venda.data_venda)}</td>
                                    <td>
                                        <span class="status-badge status-${venda.status_pagamento}">
                                            ${venda.status_pagamento.charAt(0).toUpperCase() + venda.status_pagamento.slice(1)}
                                        </span>
                                    </td>
                                    <td>${venda.codigo_pagamento}</td>
                                    <td>
                                        <div class="row-actions">
                                            <a href="#" class="caene-ver-venda" data-id="${venda.id}">Ver detalhes</a>
                                        </div>
                                    </td>
                                </tr>
                            `;
                        });
                    } else {
                        html = '<tr><td colspan="8">Nenhuma venda encontrada.</td></tr>';
                    }
                    
                    $('#caene-vendas-lista').html(html);
                    
                    // Atualizar paginação
                    $('#caene-pagination-showing').text(vendas.length);
                    $('#caene-pagination-total').text(response.data.total);
                    $('#caene-pagination-current').text('Página ' + currentPage + ' de ' + totalPages);
                    
                    $('#caene-pagination-prev').prop('disabled', currentPage <= 1);
                    $('#caene-pagination-next').prop('disabled', currentPage >= totalPages);
                    
                    // Adicionar evento para visualizar detalhes da venda
                    $('.caene-ver-venda').on('click', function(e) {
                        e.preventDefault();
                        const vendaId = $(this).data('id');
                        abrirDetalhesVenda(vendaId);
                    });
                } else {
                    mostrarMensagem('error', response.data);
                }
            },
            error: function() {
                mostrarMensagem('error', 'Erro ao carregar vendas. Tente novamente.');
            }
        });
    }
    
    // Função para formatar data
    function formatarData(dataString) {
        const data = new Date(dataString);
        return data.toLocaleDateString('pt-BR') + ' ' + data.toLocaleTimeString('pt-BR');
    }
    
    // Função para abrir detalhes da venda (simulada)
    function abrirDetalhesVenda(vendaId) {
        vendaIdAtual = vendaId;
        
        // Dados simulados - em uma implementação real, isso viria do servidor
        const vendaRow = $('tr[data-id="' + vendaId + '"]');
        
        $('#venda-produto-nome').text(vendaRow.find('td:eq(1)').text());
        $('#venda-produto-codigo').text(vendaId);
        $('#venda-produto-preco').text(vendaRow.find('td:eq(3)').text().replace('R$ ', '').replace(',', '.'));
        $('#venda-quantidade').text(vendaRow.find('td:eq(2)').text());
        $('#venda-valor-total').text(vendaRow.find('td:eq(3)').text().replace('R$ ', ''));
        $('#venda-data').text(vendaRow.find('td:eq(4)').text());
        $('#venda-status').text(vendaRow.find('td:eq(5)').text().trim());
        $('#venda-codigo').text(vendaRow.find('td:eq(6)').text());
        
        // Selecionar o status atual no dropdown
        $('#caene-update-status').val(vendaRow.find('.status-badge').attr('class').replace('status-badge status-', ''));
        
        // Gerar QR Code para a venda
        gerarQRCode(vendaId, vendaRow.find('td:eq(1)').text(), vendaRow.find('td:eq(3)').text().replace('R$ ', '').replace(',', '.'));
        
        // Exibir modal
        $('#caene-venda-modal').fadeIn();
    }
    
    // Função para exportar vendas (simulada)
    function exportarVendas(formato) {
        // Simulação de exportação
        mostrarMensagem('info', 'Exportação de vendas em formato ' + formato.toUpperCase() + ' iniciada...');
        
        setTimeout(function() {
            mostrarMensagem('success', 'Exportação concluída. O download começará automaticamente.');
            
            // Simular download
            const a = document.createElement('a');
            a.href = '#';
            a.download = 'vendas-caene.' + formato;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
        }, 1500);
    }

})(jQuery);
