<?php
/**
 * Fired during plugin deactivation
 *
 * @since      1.0.0
 */

class Caene_Deactivator {

    /**
     * Ações realizadas durante a desativação do plugin
     *
     * @since    1.0.0
     */
    public static function deactivate() {
        // Por enquanto não vamos excluir os dados para preservar o histórico
        // Se o usuário quiser excluir completamente, usaria o uninstall.php
    }
}
