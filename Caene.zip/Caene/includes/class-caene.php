<?php
/**
 * A classe principal do plugin
 *
 * @since      1.0.0
 */

class Caene {

    /**
     * O loader responsável por manter e registrar todos os hooks do plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      Caene_Loader    $loader    Mantém e registra todos os hooks para o plugin.
     */
    protected $loader;

    /**
     * O identificador único deste plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      string    $plugin_name    O nome ou identificador único deste plugin.
     */
    protected $plugin_name;

    /**
     * A versão atual do plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      string    $version    A versão atual do plugin.
     */
    protected $version;

    /**
     * Define a funcionalidade principal do plugin.
     *
     * Configura o nome e a versão do plugin que podem ser usados em todo o plugin.
     * Carrega as dependências, define as localidades e registra os hooks para o painel admin e
     * para o lado público do site.
     *
     * @since    1.0.0
     */
    public function __construct() {
        if (defined('CAENE_VERSION')) {
            $this->version = CAENE_VERSION;
        } else {
            $this->version = '1.0.0';
        }
        $this->plugin_name = 'caene-gestao-estoque';

        $this->load_dependencies();
        $this->set_locale();
        $this->define_admin_hooks();
        $this->define_public_hooks();
    }

    /**
     * Carrega as dependências necessárias para este plugin.
     *
     * Inclui os seguintes arquivos que compõem o plugin:
     *
     * - Caene_Loader. Orquestra os hooks do plugin.
     * - Caene_i18n. Define a funcionalidade de internacionalização.
     * - Caene_Admin. Define todos os hooks do painel administrativo.
     * - Caene_Public. Define todos os hooks do lado público.
     *
     * @since    1.0.0
     * @access   private
     */
    private function load_dependencies() {

        /**
         * A classe responsável por orquestrar as ações e filtros do plugin principal.
         */
        $this->loader = new Caene_Loader();

    }

    /**
     * Define a localização para o plugin para internacionalização.
     *
     * @since    1.0.0
     * @access   private
     */
    private function set_locale() {
        add_action('plugins_loaded', array($this, 'load_plugin_textdomain'));
    }

    /**
     * Carrega o domínio de texto do plugin para tradução.
     * 
     * @since    1.0.0
     */
    public function load_plugin_textdomain() {
        load_plugin_textdomain(
            'caene-gestao-estoque',
            false,
            dirname(dirname(plugin_basename(__FILE__))) . '/languages/'
        );
    }

    /**
     * Registra todos os hooks relacionados à funcionalidade administrativa do plugin.
     *
     * @since    1.0.0
     * @access   private
     */
    private function define_admin_hooks() {
        $plugin_admin = new Caene_Admin($this->get_plugin_name(), $this->get_version());

        $this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_styles');
        $this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts');
        
        // Menu do painel administrativo
        $this->loader->add_action('admin_menu', $plugin_admin, 'add_plugin_admin_menu');
        
        // AJAX para salvar configurações
        $this->loader->add_action('wp_ajax_caene_save_settings', $plugin_admin, 'ajax_save_settings');
        
        // AJAX para gerenciar produtos
        $this->loader->add_action('wp_ajax_caene_add_product', $plugin_admin, 'ajax_add_product');
        $this->loader->add_action('wp_ajax_caene_edit_product', $plugin_admin, 'ajax_edit_product');
        $this->loader->add_action('wp_ajax_caene_delete_product', $plugin_admin, 'ajax_delete_product');
        $this->loader->add_action('wp_ajax_caene_bulk_actions', $plugin_admin, 'ajax_bulk_actions');
        
        // AJAX para gerenciar vendas
        $this->loader->add_action('wp_ajax_caene_get_sales', $plugin_admin, 'ajax_get_sales');
        
        // Upload de imagens
        $this->loader->add_action('wp_ajax_caene_upload_image', $plugin_admin, 'ajax_upload_image');
    }

    /**
     * Registra todos os hooks relacionados à funcionalidade pública do plugin.
     *
     * @since    1.0.0
     * @access   private
     */
    private function define_public_hooks() {
        $plugin_public = new Caene_Public($this->get_plugin_name(), $this->get_version());

        $this->loader->add_action('wp_enqueue_scripts', $plugin_public, 'enqueue_styles');
        $this->loader->add_action('wp_enqueue_scripts', $plugin_public, 'enqueue_scripts');
        
        // Adicionar shortcode para exibir o sistema
        $this->loader->add_action('init', $plugin_public, 'register_shortcodes');
        
        // AJAX para clientes
        $this->loader->add_action('wp_ajax_caene_get_products', $plugin_public, 'ajax_get_products');
        $this->loader->add_action('wp_ajax_nopriv_caene_get_products', $plugin_public, 'ajax_get_products');
        
        // AJAX para pagamentos
        $this->loader->add_action('wp_ajax_caene_generate_payment', $plugin_public, 'ajax_generate_payment');
        $this->loader->add_action('wp_ajax_nopriv_caene_generate_payment', $plugin_public, 'ajax_generate_payment');
    }

    /**
     * Executa o loader para executar todos os hooks com WordPress.
     *
     * @since    1.0.0
     */
    public function run() {
        $this->loader->run();
    }

    /**
     * O nome do plugin usado para identificá-lo dentro do contexto do WordPress.
     *
     * @since     1.0.0
     * @return    string    O nome do plugin.
     */
    public function get_plugin_name() {
        return $this->plugin_name;
    }

    /**
     * A referência à classe que orquestra os hooks com o plugin.
     *
     * @since     1.0.0
     * @return    Caene_Loader    Orquestra os hooks do plugin.
     */
    public function get_loader() {
        return $this->loader;
    }

    /**
     * Recupera o número da versão do plugin.
     *
     * @since     1.0.0
     * @return    string    O número da versão do plugin.
     */
    public function get_version() {
        return $this->version;
    }
}
