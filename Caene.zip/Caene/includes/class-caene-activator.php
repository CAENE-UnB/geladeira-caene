<?php
/**
 * Fired during plugin activation
 *
 * @since      1.0.0
 */

class Caene_Activator {

    /**
     * Cria as tabelas necessárias no banco de dados e configurações iniciais
     *
     * @since    1.0.0
     */
    public static function activate() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        
        // Tabela de produtos
        $table_produtos = $wpdb->prefix . 'caene_produtos';
        $sql_produtos = "CREATE TABLE $table_produtos (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            nome varchar(255) NOT NULL,
            descricao text NOT NULL,
            preco decimal(10,2) NOT NULL,
            quantidade int(11) NOT NULL,
            codigo_barras varchar(100),
            imagem varchar(255),
            categoria varchar(100),
            visivel tinyint(1) DEFAULT 1,
            data_criacao datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        
        // Tabela de vendas/pagamentos
        $table_vendas = $wpdb->prefix . 'caene_vendas';
        $sql_vendas = "CREATE TABLE $table_vendas (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            produto_id mediumint(9) NOT NULL,
            quantidade int(11) NOT NULL,
            valor_total decimal(10,2) NOT NULL,
            data_venda datetime DEFAULT CURRENT_TIMESTAMP,
            status_pagamento varchar(50) DEFAULT 'pendente',
            codigo_pagamento varchar(255),
            dados_qrcode text,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        
        // Tabela de configurações
        $table_config = $wpdb->prefix . 'caene_configuracoes';
        $sql_config = "CREATE TABLE $table_config (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            logo_url varchar(255),
            cor_primaria varchar(50) DEFAULT '#3498db',
            cor_secundaria varchar(50) DEFAULT '#2ecc71',
            cor_texto varchar(50) DEFAULT '#333333',
            cor_fundo varchar(50) DEFAULT '#ffffff',
            usar_gradiente tinyint(1) DEFAULT 0,
            dados_servidor_uni text,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_produtos);
        dbDelta($sql_vendas);
        dbDelta($sql_config);
        
        // Inserir configuração padrão se não existir
        $config_count = $wpdb->get_var("SELECT COUNT(*) FROM $table_config");
        if ($config_count == 0) {
            $wpdb->insert(
                $table_config,
                array(
                    'logo_url' => '',
                    'cor_primaria' => '#3498db',
                    'cor_secundaria' => '#2ecc71',
                    'cor_texto' => '#333333',
                    'cor_fundo' => '#ffffff',
                    'usar_gradiente' => 0,
                    'dados_servidor_uni' => ''
                )
            );
        }
        
        // Criar página de visualização do sistema se não existir
        $page_exists = $wpdb->get_var($wpdb->prepare("SELECT ID FROM {$wpdb->posts} WHERE post_name = %s AND post_type = 'page'", 'caene-gestao-estoque'));
        if (!$page_exists) {
            wp_insert_post(array(
                'post_title' => 'Sistema de Gestão de Estoque',
                'post_name' => 'caene-gestao-estoque',
                'post_status' => 'publish',
                'post_type' => 'page',
                'post_content' => '[caene_sistema_estoque]'
            ));
        }
    }
}
