<?php
/**
 * A funcionalidade pública do plugin.
 *
 * @since      1.0.0
 */

class Caene_Public {

    /**
     * O ID deste plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    O ID deste plugin.
     */
    private $plugin_name;

    /**
     * A versão deste plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    A versão atual deste plugin.
     */
    private $version;

    /**
     * Inicializa a classe e define suas propriedades.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       O nome do plugin.
     * @param      string    $version    A versão do plugin.
     */
    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
    }

    /**
     * Registra os estilos para a área pública.
     *
     * @since    1.0.0
     */
    public function enqueue_styles() {
        wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/caene-public.css', array(), $this->version, 'all');
        
        // Adicionar estilos dinâmicos com base nas configurações
        global $wpdb;
        $table_config = $wpdb->prefix . 'caene_configuracoes';
        $config = $wpdb->get_row("SELECT * FROM $table_config WHERE id = 1");
        
        if ($config) {
            $custom_css = "
                .caene-sistema {
                    --cor-primaria: {$config->cor_primaria};
                    --cor-secundaria: {$config->cor_secundaria};
                    --cor-texto: {$config->cor_texto};
                    --cor-fundo: {$config->cor_fundo};
                }
                
                .caene-cabecalho {
                    background-color: {$config->cor_primaria};
                    " . ($config->usar_gradiente ? "background-image: linear-gradient(135deg, {$config->cor_primaria}, {$config->cor_secundaria});" : "") . "
                }
                
                .caene-botao {
                    background-color: {$config->cor_secundaria};
                }
                
                .caene-botao:hover {
                    background-color: " . $this->adjustBrightness($config->cor_secundaria, -15) . ";
                }
            ";
            
            wp_add_inline_style($this->plugin_name, $custom_css);
        }
    }

    /**
     * Registra os scripts para a área pública.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts() {
        wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/caene-public.js', array('jquery'), $this->version, false);
        
        // Adicionar biblioteca para QR Code
        wp_enqueue_script('qrcode-js', 'https://cdn.jsdelivr.net/npm/qrcode-generator@1.4.4/qrcode.min.js', array(), '1.4.4', false);
        
        // Adicionar objeto de localização para o AJAX
        wp_localize_script($this->plugin_name, 'caene_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('caene-ajax-nonce')
        ));
    }
    
    /**
     * Registra os shortcodes do plugin.
     *
     * @since    1.0.0
     */
    public function register_shortcodes() {
        add_shortcode('caene_sistema_estoque', array($this, 'render_sistema_estoque'));
    }
    
    /**
     * Renderiza o shortcode do sistema de estoque.
     *
     * @since    1.0.0
     * @param    array    $atts    Atributos do shortcode.
     * @return   string             Conteúdo HTML do shortcode.
     */
    public function render_sistema_estoque($atts) {
        // Mesclar atributos com padrões
        $atts = shortcode_atts(array(
            'categoria' => '',
            'ordenar' => 'nome',
            'ordem' => 'asc',
            'limite' => -1
        ), $atts, 'caene_sistema_estoque');
        
        // Obter configurações
        global $wpdb;
        $table_config = $wpdb->prefix . 'caene_configuracoes';
        $config = $wpdb->get_row("SELECT * FROM $table_config WHERE id = 1");
        
        // Iniciar buffer de saída
        ob_start();
        
        // Incluir template
        include_once 'partials/caene-public-display.php';
        
        // Retornar conteúdo do buffer
        return ob_get_clean();
    }
    
    /**
     * Processa a obtenção de produtos via AJAX
     *
     * @since    1.0.0
     */
    public function ajax_get_products() {
        // Verificar nonce para segurança
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'caene-ajax-nonce')) {
            wp_send_json_error('Erro de segurança. Tente novamente.');
        }

        global $wpdb;
        $table_produtos = $wpdb->prefix . 'caene_produtos';
        
        // Parâmetros
        $categoria = isset($_POST['categoria']) ? sanitize_text_field($_POST['categoria']) : '';
        $busca = isset($_POST['busca']) ? sanitize_text_field($_POST['busca']) : '';
        $ordenar = isset($_POST['ordenar']) ? sanitize_text_field($_POST['ordenar']) : 'nome';
        $ordem = isset($_POST['ordem']) ? sanitize_text_field($_POST['ordem']) : 'asc';
        
        // Construir consulta
        $where = "WHERE visivel = 1";
        if (!empty($categoria)) {
            $where .= $wpdb->prepare(" AND categoria = %s", $categoria);
        }
        if (!empty($busca)) {
            $where .= $wpdb->prepare(" AND (nome LIKE %s OR descricao LIKE %s)", 
                '%' . $wpdb->esc_like($busca) . '%',
                '%' . $wpdb->esc_like($busca) . '%'
            );
        }
        
        // Validar ordenação
        $valid_order_columns = ['nome', 'preco', 'data_criacao'];
        if (!in_array($ordenar, $valid_order_columns)) {
            $ordenar = 'nome';
        }
        
        $ordem = strtoupper($ordem) === 'DESC' ? 'DESC' : 'ASC';
        
        // Consulta final
        $query = "SELECT * FROM $table_produtos $where ORDER BY $ordenar $ordem";
        $produtos = $wpdb->get_results($query);
        
        wp_send_json_success($produtos);
    }
    
    /**
     * Processa a geração de pagamento via AJAX
     *
     * @since    1.0.0
     */
    public function ajax_generate_payment() {
        // Verificar nonce para segurança
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'caene-ajax-nonce')) {
            wp_send_json_error('Erro de segurança. Tente novamente.');
        }

        global $wpdb;
        $table_produtos = $wpdb->prefix . 'caene_produtos';
        $table_vendas = $wpdb->prefix . 'caene_vendas';
        
        // Obter dados do produto
        $produto_id = isset($_POST['produto_id']) ? intval($_POST['produto_id']) : 0;
        $quantidade = isset($_POST['quantidade']) ? intval($_POST['quantidade']) : 1;
        
        if ($produto_id <= 0) {
            wp_send_json_error('Produto inválido.');
        }
        
        if ($quantidade <= 0) {
            wp_send_json_error('Quantidade inválida.');
        }
        
        // Obter informações do produto
        $produto = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_produtos WHERE id = %d AND visivel = 1", $produto_id));
        
        if (!$produto) {
            wp_send_json_error('Produto não encontrado ou não disponível.');
        }
        
        // Verificar estoque
        if ($produto->quantidade < $quantidade) {
            wp_send_json_error('Quantidade solicitada não disponível em estoque.');
        }
        
        // Calcular valor total
        $valor_total = $produto->preco * $quantidade;
        
        // Gerar código de pagamento
        $timestamp = time();
        $codigo_pagamento = 'CAENE' . $produto_id . $timestamp . $this->calcular_crc($produto_id . $valor_total . $timestamp);
        
        // Gerar dados do QR Code (payload PIX simulado)
        $dados_qrcode = $this->gerar_payload_pix($produto->nome, $valor_total, $codigo_pagamento);
        
        // Registrar venda no banco de dados
        $wpdb->insert(
            $table_vendas,
            array(
                'produto_id' => $produto_id,
                'quantidade' => $quantidade,
                'valor_total' => $valor_total,
                'data_venda' => current_time('mysql'),
                'status_pagamento' => 'pendente',
                'codigo_pagamento' => $codigo_pagamento,
                'dados_qrcode' => $dados_qrcode
            )
        );
        
        $venda_id = $wpdb->insert_id;
        
        // Atualizar estoque do produto
        $wpdb->update(
            $table_produtos,
            array('quantidade' => $produto->quantidade - $quantidade),
            array('id' => $produto_id)
        );
        
        // Retornar informações para exibição do QR Code
        wp_send_json_success(array(
            'venda_id' => $venda_id,
            'produto_nome' => $produto->nome,
            'valor_total' => number_format($valor_total, 2, ',', '.'),
            'codigo_pagamento' => $codigo_pagamento,
            'quantidade' => $quantidade,
            'dados_qrcode' => $dados_qrcode
        ));
    }
    
    /**
     * Calcula o CRC para verificação
     *
     * @since    1.0.0
     * @param    string    $data    Dados para calcular o CRC.
     * @return   string             CRC calculado.
     */
    private function calcular_crc($data) {
        $crc = 0;
        for ($i = 0; $i < strlen($data); $i++) {
            $crc = (($crc << 5) + $crc) + ord($data[$i]);
        }
        return sprintf('%04d', abs($crc % 10000));
    }
    
    /**
     * Gera um payload PIX (simulado)
     *
     * @since    1.0.0
     * @param    string    $nome_produto    Nome do produto.
     * @param    float     $valor           Valor do pagamento.
     * @param    string    $codigo          Código de referência.
     * @return   string                     Payload PIX.
     */
    private function gerar_payload_pix($nome_produto, $valor, $codigo) {
        // Este é um payload PIX simulado para fins de demonstração
        // Em uma implementação real, seguiria o padrão do Banco Central
        
        $payload = array(
            'chave' => 'caene@exemplo.com.br',
            'beneficiario' => 'CAENE Universidade',
            'cidade' => 'São Paulo',
            'valor' => number_format($valor, 2, '.', ''),
            'descricao' => 'Pagamento: ' . $nome_produto,
            'identificador' => $codigo,
            'crc' => $this->calcular_crc($codigo . $valor)
        );
        
        return json_encode($payload);
    }
    
    /**
     * Ajusta o brilho de uma cor HEX
     *
     * @since    1.0.0
     * @param    string    $hex      Cor em formato hexadecimal.
     * @param    int       $steps    Passos para ajuste (-255 a 255).
     * @return   string              Cor ajustada em formato hexadecimal.
     */
    private function adjustBrightness($hex, $steps) {
        // Remover # se presente
        $hex = ltrim($hex, '#');
        
        // Converter para RGB
        $r = hexdec(substr($hex, 0, 2));
        $g = hexdec(substr($hex, 2, 2));
        $b = hexdec(substr($hex, 4, 2));
        
        // Ajustar brilho
        $r = max(0, min(255, $r + $steps));
        $g = max(0, min(255, $g + $steps));
        $b = max(0, min(255, $b + $steps));
        
        // Converter de volta para HEX
        return '#' . sprintf('%02x%02x%02x', $r, $g, $b);
    }
}
