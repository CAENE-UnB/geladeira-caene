<?php
/**
 * Fornece a interface pública do plugin
 *
 * @since      1.0.0
 */
?>

<div class="caene-sistema">
    <!-- Cabeçalho -->
    <div class="caene-cabecalho">
        <div class="caene-logo">
            <?php if (!empty($config->logo_url)) : ?>
                <img src="<?php echo esc_url($config->logo_url); ?>" alt="Logo">
            <?php endif; ?>
            <h1>Sistema de Gestão de Estoque</h1>
        </div>
        <div class="caene-busca">
            <input type="text" id="caene-busca-input" placeholder="Buscar produtos...">
            <button id="caene-busca-botao" type="button">Buscar</button>
        </div>
    </div>
    
    <!-- Filtros -->
    <div class="caene-filtros">
        <div class="caene-filtro-item">
            <label for="caene-filtro-categoria">Categoria:</label>
            <select id="caene-filtro-categoria">
                <option value="">Todas as categorias</option>
                <!-- Categorias serão carregadas via JavaScript -->
            </select>
        </div>
        <div class="caene-filtro-item">
            <label for="caene-filtro-ordenar">Ordenar por:</label>
            <select id="caene-filtro-ordenar">
                <option value="nome-asc">Nome (A-Z)</option>
                <option value="nome-desc">Nome (Z-A)</option>
                <option value="preco-asc">Preço (menor para maior)</option>
                <option value="preco-desc">Preço (maior para menor)</option>
                <option value="data_criacao-desc">Mais recentes</option>
                <option value="data_criacao-asc">Mais antigos</option>
            </select>
        </div>
    </div>
    
    <!-- Grade de produtos -->
    <div id="caene-produtos" class="caene-produtos">
        <!-- Produtos serão carregados via JavaScript -->
        <div class="caene-carregando">
            <div class="caene-spinner"></div>
            Carregando produtos...
        </div>
    </div>
    
    <!-- Rodapé -->
    <div class="caene-rodape">
        <p>&copy; <?php echo date('Y'); ?> Sistema de Gestão de Estoque. Todos os direitos reservados.</p>
    </div>
    
    <!-- Modal de produto -->
    <div id="caene-produto-modal" class="caene-modal">
        <div class="caene-modal-content">
            <span class="caene-modal-fechar">&times;</span>
            <h2>Detalhes do Produto</h2>
            
            <div class="caene-produto-detalhes">
                <div id="caene-produto-imagem-modal" class="caene-produto-imagem-grande">
                    <!-- Imagem do produto -->
                </div>
                
                <div class="caene-produto-dados">
                    <h3 id="caene-produto-nome-modal"></h3>
                    <p id="caene-produto-descricao-modal"></p>
                    <div id="caene-produto-preco-modal" class="caene-produto-preco-grande"></div>
                    
                    <div class="caene-quantidade">
                        <label for="caene-quantidade">Quantidade:</label>
                        <button type="button" id="caene-diminuir-quantidade">-</button>
                        <input type="number" id="caene-quantidade" value="1" min="1">
                        <button type="button" id="caene-aumentar-quantidade">+</button>
                    </div>
                    
                    <button type="button" id="caene-gerar-pagamento" class="caene-botao">Gerar Pagamento</button>
                </div>
            </div>
            
            <!-- QR Code de pagamento -->
            <div class="caene-qrcode-container" style="display: none;">
                <h3>QR Code para Pagamento</h3>
                
                <div id="caene-qrcode-imagem" class="caene-qrcode-imagem">
                    <!-- QR Code será gerado via JavaScript -->
                </div>
                
                <div class="caene-qrcode-info">
                    <p><strong>Produto:</strong> <span id="caene-qrcode-produto"></span></p>
                    <p><strong>Valor:</strong> <span id="caene-qrcode-valor"></span></p>
                    <p><strong>Código de Pagamento:</strong> <span id="caene-qrcode-codigo"></span></p>
                </div>
                
                <div class="caene-qrcode-botoes">
                    <button type="button" id="caene-baixar-qrcode" class="caene-botao">Baixar QR Code</button>
                    <button type="button" id="caene-copiar-codigo" class="caene-botao">Copiar Código</button>
                </div>
            </div>
        </div>
    </div>
</div>
