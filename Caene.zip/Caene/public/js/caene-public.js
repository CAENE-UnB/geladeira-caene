/**
 * JavaScript para a interface pública do plugin Caene Gestão de Estoque
 */
(function($) {
    'use strict';

    // Variáveis globais
    let produtosCarregados = [];
    let categorias = [];
    let produtoAtual = null;
    let quantidadeAtual = 1;

    // Inicialização ao carregar a página
    $(document).ready(function() {
        // Carregar produtos
        carregarProdutos();

        // Eventos de busca
        $('#caene-busca-input').on('keypress', function(e) {
            if (e.which === 13) {
                buscarProdutos();
            }
        });

        $('#caene-busca-botao').on('click', function() {
            buscarProdutos();
        });

        // Eventos de filtro
        $('#caene-filtro-categoria').on('change', function() {
            filtrarProdutos();
        });

        $('#caene-filtro-ordenar').on('change', function() {
            ordenarProdutos();
        });

        // Fechar modais
        $('.caene-modal-fechar').on('click', function() {
            $('.caene-modal').hide();
        });

        // Clicar fora do modal para fechar
        $(window).on('click', function(e) {
            if ($(e.target).hasClass('caene-modal')) {
                $('.caene-modal').hide();
            }
        });

        // Botões de quantidade
        $('#caene-diminuir-quantidade').on('click', function() {
            if (quantidadeAtual > 1) {
                quantidadeAtual--;
                $('#caene-quantidade').val(quantidadeAtual);
            }
        });

        $('#caene-aumentar-quantidade').on('click', function() {
            quantidadeAtual++;
            $('#caene-quantidade').val(quantidadeAtual);
        });

        // Botão de comprar/gerar pagamento
        $('#caene-gerar-pagamento').on('click', function() {
            gerarPagamento();
        });

        // Botões do QR Code
        $('#caene-baixar-qrcode').on('click', function() {
            baixarQRCode();
        });

        $('#caene-copiar-codigo').on('click', function() {
            copiarCodigo();
        });
    });

    // Função para carregar produtos
    function carregarProdutos(busca = '', categoria = '', ordenar = 'nome', ordem = 'asc') {
        $('#caene-produtos').html('<div class="caene-carregando"><div class="caene-spinner"></div>Carregando produtos...</div>');

        $.ajax({
            url: caene_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'caene_get_products',
                busca: busca,
                categoria: categoria,
                ordenar: ordenar,
                ordem: ordem,
                nonce: caene_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    produtosCarregados = response.data;
                    
                    if (produtosCarregados.length === 0) {
                        exibirSemProdutos();
                    } else {
                        exibirProdutos(produtosCarregados);
                        atualizarCategorias(produtosCarregados);
                    }
                } else {
                    mostrarMensagem('erro', 'Erro ao carregar produtos: ' + response.data);
                }
            },
            error: function() {
                mostrarMensagem('erro', 'Erro ao comunicar com o servidor. Tente novamente mais tarde.');
                exibirSemProdutos();
            }
        });
    }

    // Função para exibir produtos
    function exibirProdutos(produtos) {
        let html = '';

        produtos.forEach(function(produto) {
            html += `
                <div class="caene-produto" data-id="${produto.id}">
                    <div class="caene-produto-imagem">
                        ${produto.imagem ? `<img src="${produto.imagem}" alt="${produto.nome}">` : ''}
                    </div>
                    <div class="caene-produto-info">
                        <h3 class="caene-produto-nome">${produto.nome}</h3>
                        <div class="caene-produto-descricao">${produto.descricao}</div>
                        <div class="caene-produto-preco">R$ ${parseFloat(produto.preco).toFixed(2).replace('.', ',')}</div>
                        <button class="caene-botao caene-botao-comprar" data-id="${produto.id}">Comprar</button>
                    </div>
                </div>
            `;
        });

        $('#caene-produtos').html(html);

        // Adicionar evento de clique para os botões de compra
        $('.caene-botao-comprar').on('click', function() {
            const produtoId = $(this).data('id');
            abrirModalProduto(produtoId);
        });
    }

    // Função para exibir mensagem de nenhum produto encontrado
    function exibirSemProdutos() {
        const html = `
            <div class="caene-sem-produtos">
                <h3>Nenhum produto encontrado</h3>
                <p>Tente mudar os filtros ou realizar uma nova busca.</p>
            </div>
        `;

        $('#caene-produtos').html(html);
    }

    // Função para atualizar o dropdown de categorias
    function atualizarCategorias(produtos) {
        // Extrair categorias únicas
        const todasCategorias = produtos
            .map(produto => produto.categoria)
            .filter((cat, index, self) => cat && self.indexOf(cat) === index);
        
        categorias = todasCategorias;
        
        // Atualizar dropdown apenas se não tiver sido carregado antes
        const dropdown = $('#caene-filtro-categoria');
        if (dropdown.find('option').length <= 1) {
            let opcoesHtml = '<option value="">Todas as categorias</option>';
            
            categorias.forEach(function(categoria) {
                opcoesHtml += `<option value="${categoria}">${categoria}</option>`;
            });
            
            dropdown.html(opcoesHtml);
        }
    }

    // Função para buscar produtos
    function buscarProdutos() {
        const busca = $('#caene-busca-input').val().trim();
        const categoria = $('#caene-filtro-categoria').val();
        const ordenar = $('#caene-filtro-ordenar').val().split('-')[0];
        const ordem = $('#caene-filtro-ordenar').val().split('-')[1] || 'asc';
        
        carregarProdutos(busca, categoria, ordenar, ordem);
    }

    // Função para filtrar produtos por categoria
    function filtrarProdutos() {
        const busca = $('#caene-busca-input').val().trim();
        const categoria = $('#caene-filtro-categoria').val();
        const ordenar = $('#caene-filtro-ordenar').val().split('-')[0];
        const ordem = $('#caene-filtro-ordenar').val().split('-')[1] || 'asc';
        
        carregarProdutos(busca, categoria, ordenar, ordem);
    }

    // Função para ordenar produtos
    function ordenarProdutos() {
        const busca = $('#caene-busca-input').val().trim();
        const categoria = $('#caene-filtro-categoria').val();
        const ordenar = $('#caene-filtro-ordenar').val().split('-')[0];
        const ordem = $('#caene-filtro-ordenar').val().split('-')[1] || 'asc';
        
        carregarProdutos(busca, categoria, ordenar, ordem);
    }

    // Função para abrir modal de produto
    function abrirModalProduto(produtoId) {
        // Encontrar o produto pelo ID
        produtoAtual = produtosCarregados.find(p => p.id == produtoId);
        
        if (!produtoAtual) {
            mostrarMensagem('erro', 'Produto não encontrado.');
            return;
        }
        
        // Resetar a quantidade
        quantidadeAtual = 1;
        $('#caene-quantidade').val(quantidadeAtual);
        
        // Preencher os dados do produto no modal
        $('#caene-produto-nome-modal').text(produtoAtual.nome);
        $('#caene-produto-descricao-modal').text(produtoAtual.descricao);
        $('#caene-produto-preco-modal').text('R$ ' + parseFloat(produtoAtual.preco).toFixed(2).replace('.', ','));
        
        // Imagem do produto
        if (produtoAtual.imagem) {
            $('#caene-produto-imagem-modal').html(`<img src="${produtoAtual.imagem}" alt="${produtoAtual.nome}">`);
        } else {
            $('#caene-produto-imagem-modal').html('');
        }
        
        // Ocultar a parte de QR Code
        $('.caene-qrcode-container').hide();
        
        // Exibir o modal
        $('#caene-produto-modal').css('display', 'flex');
    }

    // Função para gerar pagamento
    function gerarPagamento() {
        if (!produtoAtual) {
            mostrarMensagem('erro', 'Nenhum produto selecionado.');
            return;
        }
        
        quantidadeAtual = parseInt($('#caene-quantidade').val());
        
        if (isNaN(quantidadeAtual) || quantidadeAtual <= 0) {
            mostrarMensagem('erro', 'Quantidade inválida.');
            return;
        }
        
        $('#caene-gerar-pagamento').text('Processando...').prop('disabled', true);
        
        $.ajax({
            url: caene_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'caene_generate_payment',
                produto_id: produtoAtual.id,
                quantidade: quantidadeAtual,
                nonce: caene_ajax.nonce
            },
            success: function(response) {
                $('#caene-gerar-pagamento').text('Gerar Pagamento').prop('disabled', false);
                
                if (response.success) {
                    const dados = response.data;
                    
                    // Exibir informações do pagamento
                    $('#caene-qrcode-produto').text(dados.produto_nome);
                    $('#caene-qrcode-valor').text('R$ ' + dados.valor_total);
                    $('#caene-qrcode-codigo').text(dados.codigo_pagamento);
                    
                    // Gerar QR Code
                    gerarQRCode(dados.dados_qrcode);
                    
                    // Exibir seção de QR Code
                    $('.caene-qrcode-container').show();
                    
                    // Rolar para a seção de QR Code
                    $('.caene-qrcode-container')[0].scrollIntoView({ behavior: 'smooth' });
                } else {
                    mostrarMensagem('erro', response.data);
                }
            },
            error: function() {
                $('#caene-gerar-pagamento').text('Gerar Pagamento').prop('disabled', false);
                mostrarMensagem('erro', 'Erro ao comunicar com o servidor. Tente novamente mais tarde.');
            }
        });
    }

    // Função para gerar QR Code
    function gerarQRCode(dados) {
        // Limpar container do QR Code
        $('#caene-qrcode-imagem').empty();
        
        try {
            // Verificar se a biblioteca qrcode está disponível
            if (typeof qrcode === 'function') {
                // Criar QR Code usando a biblioteca qrcode.js
                const qr = qrcode(0, 'M');
                qr.addData(dados);
                qr.make();
                
                $('#caene-qrcode-imagem').html(qr.createImgTag(5));
            } else {
                // Fallback para quando a biblioteca não estiver disponível
                $('#caene-qrcode-imagem').html(`
                    <div style="width:200px;height:200px;background:#f1f1f1;display:flex;align-items:center;justify-content:center;text-align:center;">
                        QR Code indisponível.<br>Use o código de pagamento abaixo.
                    </div>
                `);
            }
        } catch (e) {
            console.error('Erro ao gerar QR Code:', e);
            $('#caene-qrcode-imagem').html(`
                <div style="width:200px;height:200px;background:#f1f1f1;display:flex;align-items:center;justify-content:center;text-align:center;">
                    Erro ao gerar QR Code.<br>Use o código de pagamento abaixo.
                </div>
            `);
        }
    }

    // Função para baixar QR Code
    function baixarQRCode() {
        const qrCodeImg = $('#caene-qrcode-imagem img').get(0);
        
        if (qrCodeImg) {
            // Criar um canvas para manipular a imagem
            const canvas = document.createElement('canvas');
            canvas.width = qrCodeImg.width;
            canvas.height = qrCodeImg.height;
            
            // Desenhar a imagem no canvas
            const ctx = canvas.getContext('2d');
            ctx.drawImage(qrCodeImg, 0, 0);
            
            // Criar link para download
            const dataUrl = canvas.toDataURL('image/png');
            const link = document.createElement('a');
            link.href = dataUrl;
            link.download = 'qrcode-pagamento-' + $('#caene-qrcode-codigo').text() + '.png';
            link.click();
        } else {
            mostrarMensagem('erro', 'QR Code não disponível para download.');
        }
    }

    // Função para copiar código de pagamento
    function copiarCodigo() {
        const codigo = $('#caene-qrcode-codigo').text();
        
        if (navigator.clipboard) {
            navigator.clipboard.writeText(codigo)
                .then(() => {
                    $('#caene-copiar-codigo').text('Copiado!');
                    setTimeout(() => {
                        $('#caene-copiar-codigo').text('Copiar Código');
                    }, 2000);
                })
                .catch(err => {
                    console.error('Erro ao copiar: ', err);
                    copiarCodigoFallback(codigo);
                });
        } else {
            copiarCodigoFallback(codigo);
        }
    }

    // Fallback para navegadores que não suportam clipboard API
    function copiarCodigoFallback(texto) {
        const textarea = document.createElement('textarea');
        textarea.value = texto;
        textarea.style.position = 'fixed';
        document.body.appendChild(textarea);
        textarea.focus();
        textarea.select();
        
        try {
            const success = document.execCommand('copy');
            if (success) {
                $('#caene-copiar-codigo').text('Copiado!');
                setTimeout(() => {
                    $('#caene-copiar-codigo').text('Copiar Código');
                }, 2000);
            } else {
                mostrarMensagem('erro', 'Falha ao copiar o código.');
            }
        } catch (err) {
            mostrarMensagem('erro', 'Falha ao copiar o código.');
        }
        
        document.body.removeChild(textarea);
    }

    // Função para exibir mensagem
    function mostrarMensagem(tipo, texto) {
        // Remover mensagens existentes
        $('.caene-mensagem').remove();
        
        // Criar nova mensagem
        const mensagemHtml = `<div class="caene-mensagem caene-mensagem-${tipo}">${texto}</div>`;
        
        // Inserir mensagem
        $('.caene-sistema').prepend(mensagemHtml);
        
        // Rolar para a mensagem
        $('.caene-mensagem')[0].scrollIntoView({ behavior: 'smooth' });
        
        // Esconder após 5 segundos
        setTimeout(function() {
            $('.caene-mensagem').fadeOut(500, function() {
                $(this).remove();
            });
        }, 5000);
    }

})(jQuery);
